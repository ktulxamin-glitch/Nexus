package com.nexus.gamespace

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*

/** Foreground session: WakeLock + edge-pill overlay with a frosted panel. */
class GameSessionService : Service() {
    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var edge: View? = null
    private var panel: LinearLayout? = null
    private var blackout: View? = null
    private var guard: View? = null
    private var telemetry: TextView? = null
    private var wake: PowerManager.WakeLock? = null
    private var prevFilter = -1
    private val tick = object : Runnable {
        override fun run() {
            telemetry?.text = "TEMP ${"%.1f".format(Telemetry.tempC(this@GameSessionService))}°C   RAM ${Telemetry.ramPct(this@GameSessionService)}%   ${display?.refreshRate?.toInt() ?: 0}Hz"
            h.postDelayed(this, 1000)
        }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("nexus", "Nexus session", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, GameSessionService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "nexus").setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Nexus Game Space").setContentText("Session active")
            .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_pause), "End session", stop).build()).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wake = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nexus:session").apply { acquire(4 * 60 * 60 * 1000L) }
        if (edge == null && Settings.canDrawOverlays(this)) { addGuard(); addEdge(); h.post(tick) }
        return START_NOT_STICKY
    }

    private fun lp(w: Int, hgt: Int, gravity: Int, touch: Boolean = true) =
        WindowManager.LayoutParams(w, hgt, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { this.gravity = gravity }

    private fun glass(a: Int, r: Float) = GradientDrawable().apply {
        setColor(Color.argb(a, 27, 32, 40)); cornerRadius = r; setStroke(dp(1), 0x22FFFFFF)
    }

    /** 1x1 invisible overlay that pins the display to landscape while the game is on screen. */
    private fun addGuard() {
        guard = View(this)
        val l = WindowManager.LayoutParams(1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { screenOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE }
        wm.addView(guard, l)
    }

    private fun addEdge() {
        edge = View(this).apply {
            background = GradientDrawable().apply { setColor(0x44FFFFFF); cornerRadius = dp(6).toFloat() }
            alpha = 0.5f
            setOnClickListener { togglePanel() }
        }
        wm.addView(edge, lp(dp(12), dp(72), Gravity.END or Gravity.CENTER_VERTICAL))
    }

    private fun chip(label: String, onTap: (TextView) -> Unit) = TextView(this).apply {
        text = label; setTextColor(0xFFE8EEF5.toInt()); textSize = 13f; gravity = Gravity.CENTER
        setPadding(dp(14), dp(12), dp(14), dp(12)); background = glass(150, dp(14).toFloat())
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        setOnClickListener { onTap(this) }
    }
    private fun TextView.active(on: Boolean) {
        background = glass(if (on) 230 else 150, dp(14).toFloat())
        (background as GradientDrawable).setStroke(dp(1), if (on) 0xFFF4F4F5.toInt() else 0x22FFFFFF)
    }

    private fun togglePanel() {
        if (panel != null) { wm.removeView(panel); panel = null; return }
        telemetry = TextView(this).apply { setTextColor(0xFFF4F4F5.toInt()); textSize = 12f; typeface = android.graphics.Typeface.MONOSPACE }
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = glass(215, dp(24).toFloat())
            addView(telemetry)
            addView(chip("Notification Blocker") { v ->
                val nm = getSystemService(NotificationManager::class.java)
                if (!nm.isNotificationPolicyAccessGranted) {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return@chip
                }
                if (prevFilter == -1) { prevFilter = nm.currentInterruptionFilter; nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY); v.active(true) }
                else { nm.setInterruptionFilter(prevFilter); prevFilter = -1; v.active(false) }
            })
            addView(chip("Screen-Off Hanging") { showBlackout() })
            addView(chip("End session") { stopSelf() })
        }
        panel = p
        val l = lp(dp(260), -2, Gravity.END or Gravity.CENTER_VERTICAL).apply { x = dp(16) }
        if (Build.VERSION.SDK_INT >= 31) { l.flags = l.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND; l.blurBehindRadius = 30 }
        wm.addView(p, l)
    }

    /** Black overlay + brightness 0; game keeps running, WakeLock keeps CPU on. Long-press to wake. */
    private fun showBlackout() {
        if (blackout != null) return
        blackout = View(this).apply {
            setBackgroundColor(Color.BLACK)
            setOnLongClickListener { wm.removeView(this); blackout = null; true }
        }
        val l = lp(-1, -1, Gravity.TOP).apply { screenBrightness = 0f }
        wm.addView(blackout, l)
        Toast.makeText(this, "Long-press screen to wake", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        if (prevFilter != -1) getSystemService(NotificationManager::class.java).setInterruptionFilter(prevFilter)
        listOf(guard, edge, panel, blackout).forEach { v -> v?.let { runCatching { wm.removeView(it) } } }
        wake?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
