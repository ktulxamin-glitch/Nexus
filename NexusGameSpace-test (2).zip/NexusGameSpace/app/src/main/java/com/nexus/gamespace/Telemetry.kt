package com.nexus.gamespace

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.net.InetSocketAddress
import java.net.Socket

object Telemetry {
    private fun battery(c: Context) = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    fun tempC(c: Context): Float = (battery(c)?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    fun batteryPct(c: Context): Int {
        val i = battery(c) ?: return 0
        val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0); val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        return l * 100 / s
    }
    fun ramPct(c: Context): Int {
        val mi = ActivityManager.MemoryInfo()
        (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return (100 - mi.availMem * 100 / mi.totalMem).toInt()
    }
    /** TCP connect RTT in ms, or -1 on failure. Call off the main thread. */
    fun pingMs(): Int = try {
        val t = System.nanoTime()
        Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }
        ((System.nanoTime() - t) / 1_000_000).toInt()
    } catch (e: Exception) { -1 }
}
