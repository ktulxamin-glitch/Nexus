package com.nexus.gamespace

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.*

val Obsidian = Color(0xFF07080A); val Ice = Color(0xFFF4F4F5); val Warn = Color(0xFFFFB86B)
val TextPri = Color(0xFFE8EEF5); val TextSec = Color(0xFF8A95A3)

fun Modifier.glass(r: Int = 24) = this.clip(RoundedCornerShape(r.dp))
    .background(Brush.verticalGradient(listOf(Color(0xB81B2028), Color(0x8F1B2028))))
    .border(1.dp, Color(0x1FFFFFFF), RoundedCornerShape(r.dp))

class MainActivity : ComponentActivity() {
    override fun onResume() { super.onResume(); requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { NexusApp() } }
    }
}

data class Game(val pkg: String, val label: String, val icon: ImageBitmap, val isGame: Boolean)

@Composable
fun NexusApp() {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    Box(Modifier.fillMaxSize().background(Obsidian)) {
    Image(painterResource(R.drawable.bg_nexus), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = 0.7f)
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x33050505), Color(0xE6050505)))))
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 16.dp)) {
        Text("NEXUS", color = TextPri, fontSize = 22.sp, fontWeight = FontWeight.Medium, letterSpacing = 6.sp,
            modifier = Modifier.padding(vertical = 16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("LIBRARY", "DASHBOARD").forEachIndexed { i, t ->
                Text(t, color = if (tab == i) Ice else TextSec, fontSize = 12.sp, letterSpacing = 2.sp,
                    modifier = Modifier.glass(14).clickable { tab = i }.padding(horizontal = 16.dp, vertical = 10.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
        if (tab == 0) Library() else Dashboard()
    }
    }
}

@Composable
fun Library() {
    val ctx = LocalContext.current
    var games by remember { mutableStateOf(listOf<Game>()) }
    var gamesOnly by remember { mutableStateOf(true) }
    var selected by remember { mutableStateOf<Game?>(null) }
    LaunchedEffect(Unit) {
        games = withContext(Dispatchers.Default) {
            val pm = ctx.packageManager
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .filter { it.activityInfo.packageName != ctx.packageName }
                .mapNotNull { runCatching {
                    val ai = it.activityInfo.applicationInfo
                    Game(ai.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm).toBitmap(112, 112).asImageBitmap(),
                        Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME)
                }.getOrNull() }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
        }
    }
    val shown = if (gamesOnly && games.any { it.isGame }) games.filter { it.isGame } else games
    Column(Modifier.fillMaxSize()) {
        Text(if (gamesOnly) "Showing games · tap to switch to all apps" else "Showing all apps · tap for games only",
            color = TextSec, fontSize = 12.sp, modifier = Modifier.clickable { gamesOnly = !gamesOnly }.padding(bottom = 8.dp))
        if (shown.isEmpty()) Text("Loading apps…", color = TextSec, modifier = Modifier.padding(8.dp))
        LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(shown, key = { it.pkg }) { g ->
                val sel = selected?.pkg == g.pkg
                Column(Modifier.glass(20).border(1.dp, if (sel) Ice else Color.Transparent, RoundedCornerShape(20.dp))
                    .clickable { selected = g }.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(g.icon, g.label, Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)))
                    Text(g.label, color = TextPri, fontSize = 11.sp, maxLines = 1, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
        Box(Modifier.fillMaxWidth().padding(vertical = 14.dp).height(56.dp).clip(RoundedCornerShape(18.dp))
            .background(Ice.copy(alpha = if (selected != null) 0.14f else 0.05f))
            .border(1.dp, Ice.copy(alpha = if (selected != null) 0.9f else 0.25f), RoundedCornerShape(18.dp))
            .clickable(enabled = selected != null) { boostAndLaunch(ctx, selected!!.pkg) }, contentAlignment = Alignment.Center) {
            Text(if (selected != null) "BOOST & LAUNCH · ${selected!!.label}" else "SELECT A GAME", color = Ice, fontSize = 14.sp,
                letterSpacing = 3.sp, maxLines = 1, modifier = Modifier.padding(horizontal = 12.dp))
        }
    }
}

fun boostAndLaunch(ctx: Context, pkg: String) {
    if (!Settings.canDrawOverlays(ctx)) {
        Toast.makeText(ctx, "Allow 'Display over other apps' for Nexus, then try again", Toast.LENGTH_LONG).show()
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
        return
    }
    // Rotate to landscape first so the game opens already in landscape; the session's guard overlay keeps it there.
    (ctx as? Activity)?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    ContextCompat.startForegroundService(ctx, Intent(ctx, GameSessionService::class.java))
    ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) }
}

@Composable
fun Dashboard() {
    val ctx = LocalContext.current
    var temp by remember { mutableStateOf(0f) }; var ram by remember { mutableStateOf(0) }
    var bat by remember { mutableStateOf(0) }; var ping by remember { mutableStateOf(-1) }
    LaunchedEffect(Unit) {
        var n = 0
        while (true) {
            temp = Telemetry.tempC(ctx); ram = Telemetry.ramPct(ctx); bat = Telemetry.batteryPct(ctx)
            if (n++ % 5 == 0) ping = withContext(Dispatchers.IO) { Telemetry.pingMs() }
            delay(1000)
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Ring("TEMP", "%.1f°".format(temp), temp / 50f, temp > 42, Modifier.weight(1f))
            Ring("RAM", "$ram%", ram / 100f, ram > 90, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Ring("BATTERY", "$bat%", bat / 100f, bat < 15, Modifier.weight(1f))
            Ring("PING", if (ping < 0) "—" else "${ping}ms", if (ping < 0) 0f else ping / 200f, ping > 80, Modifier.weight(1f))
        }
        Text("PRO FEATURES (need Shizuku / OEM access — coming next)", color = TextSec, fontSize = 11.sp, letterSpacing = 1.sp)
        listOf("Bypass Charging · T2", "Voice Changer Hub · T1", "4D Haptic Feedback · T1").forEach {
            Text(it, color = TextSec, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().glass(18).padding(16.dp))
        }
    }
}

@Composable
fun Ring(label: String, value: String, frac: Float, warn: Boolean, modifier: Modifier) {
    Box(modifier.height(150.dp).glass(), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(112.dp)) {
            val s = Stroke(14f, cap = StrokeCap.Round)
            drawArc(Color(0x1FFFFFFF), 0f, 360f, false, style = s)
            drawArc(if (warn) Warn else Ice, -90f, 360f * frac.coerceIn(0f, 1f), false, style = s)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = TextPri, fontSize = 22.sp, fontWeight = FontWeight.Medium)
            Text(label, color = TextSec, fontSize = 10.sp, letterSpacing = 2.sp)
        }
    }
}
