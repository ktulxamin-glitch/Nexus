# Nexus Game Space — Test build (auto-landscape on launch)
1. Open this folder in Android Studio (Koala+), let Gradle sync.
2. Build > Build APK(s)  ->  app/build/outputs/apk/debug/app-debug.apk
3. Install on phone. On first BOOST & LAUNCH grant "Display over other apps".
Command line: run `gradle wrapper` once, then `./gradlew assembleDebug`.
Landscape: BOOST & LAUNCH rotates to landscape; ending the session (panel or notification) restores normal rotation.

## No PC? Build with GitHub Actions
1. Create a GitHub repo, upload the CONTENTS of this folder (including the hidden .github folder).
2. Actions tab > "Build APK" > Run workflow. Wait ~5 min.
3. Open the finished run > Artifacts > download NexusGameSpace-debug-apk, unzip, install app-debug.apk.
